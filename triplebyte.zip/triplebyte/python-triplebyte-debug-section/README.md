# Python debug exercise

To install:

    pip3 install requests
    # or in Python 2
    pip install requests

To run the already passing tests:

    python3 already_passing_tests.py

To run a failing test:

    python3 failing_test_1.py
