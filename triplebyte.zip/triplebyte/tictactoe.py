from pprint import pprint

class Board():
    def __init__(self):
        self.board = [["-","-","-"] for i in range(3)]

    def add_token(self, coord, token_type):
        x = int(coord[0])
        y = int(coord[1])
        self.board[x][y] = token_type.upper()

    def show_board(self):
        for x in self.board:
            print(f"{x[0]}|{x[1]}|{x[2]}")

    def _is_board_full(self):
        for x in self.board:
            for y in x:
                if y == "-":
                    print("True")
                    return True
                else:
                    print("False")
                    return False

    def ai_move(self):
        if self._is_board_full():
            for i, x in enumerate(self.board):
                for j, y in enumerate(x):
                    if y == "-":
                        self.board[i][j] = "O"
        else:
            raise Exception("Full Board.")

    def game_loop(self):
        full = self._is_board_full()

        while full:
            self.show_board()
            coord = input("Please provide your board move (xy eg. 01 through 22) ")
            self.add_token(coord, "X")
            self.show_board()
            self.ai_move()
            full = self._is_board_full()
                    


if __name__ == "__main__":
    try:
        board = Board()
        board.game_loop()
    except:
        board.show_board()

